[English](README.md) | [简体中文](README_CN.md) | [繁體中文](README_TW.md) | [Türkçe](README_TR.md) | [Português (Brasil)](README_PT-BR.md) | [한국어](README_KO.md) | **Français** | [Bahasa Indonesia](README_ID.md) | [Русский](README_RU.md) | [Українська](README_UA.md) | [ภาษาไทย](README_TH.md) | [Tiếng Việt](README_VI.md) | [Italiano](README_IT.md) | [Polski](README_PL.md) | [Български](README_BG.md) | [日本語](README_JA.md) | [Español](README_ES.md)

---

<div align="center">
  <img src="/assets/kernelsu_next.png" width="96" alt="KernelSU Next Logo">

  <h2>KernelSU Next</h2>
  <p><strong>Une solution root basée sur le noyau pour les appareils Android.</strong></p>

  <p>
    <a href="https://github.com/KernelSU-Next/KernelSU-Next/releases/latest">
      <img src="https://img.shields.io/github/v/release/KernelSU-Next/KernelSU-Next?label=Release&logo=github" alt="Latest Release">
    </a>
    <a href="https://github.com/KernelSU-Next/KernelSU-Next/releases">
      <img src="https://img.shields.io/github/downloads/KernelSU-Next/KernelSU-Next/total?label=Downloads&logo=github" alt="Total Downloads">
    </a>
    <a href="https://nightly.link/KernelSU-Next/KernelSU-Next/workflows/build-manager-ci/dev/manager">
      <img src="https://img.shields.io/badge/Nightly%20Release-gray?logo=hackthebox&logoColor=fff" alt="Nightly Build">
    </a>
    <a href="https://github.com/KernelSU-Next/KernelSU-Next/actions/workflows/build-manager-ci.yml">
      <img src="https://github.com/KernelSU-Next/KernelSU-Next/actions/workflows/build-manager-ci.yml/badge.svg" alt="Build Status">
    </a>
    <a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html">
      <img src="https://img.shields.io/badge/License-GPL%20v2-orange.svg?logo=gnu" alt="License: GPL v2">
    </a>
    <a href="/LICENSE">
      <img src="https://img.shields.io/github/license/KernelSU-Next/KernelSU-Next?logo=gnu" alt="GitHub License">
    </a>
    <a title="Crowdin" target="_blank" href="https://crowdin.com/project/kernelsu-next"><img src="https://badges.crowdin.net/kernelsu-next/localized.svg"></a>
  </p>
</div>

---

## 🚀 Fonctionnalités

- Gestion du `su` et des accès root basée sur le noyau.
- Système de modules basé sur [metamodules](https://kernelsu.org/guide/metamodule.html) : infrastructure extensible pour les modifications sans système.
- Chargement intégré du pilote SUSFS LKM sur les appareils GKI 2.0.
- Détection des risques qui bloque l’installation de modules suspects.
- Prise en charge de la sauvegarde et de la restauration des modules et des profils d’application.
- [Profil d'application](https://kernelsu.org/guide/app-profile.html) : enfermer le pouvoir root dans une cage.

---

## ✅ Compatibilité

KernelSU Next prend en charge les noyaux Android de **4.4 à 6.18**.

| Version du noyau | Notes de support |
|----------------------|-------------------------------------------------------------------------|
| 5.10+ (GKI 2.0)      | Prend en charge les images pré-compilées et LKM/KMI |
| 4.19 – 5.4 (GKI 1.0) | Nécessite le pilote KernelSU intégré au noyau |
| < 4.14 (EOL)         | Nécessite le pilote KernelSU (3.18+ est expérimental et peut nécessiter des backports) |

**Architectures prises en charge:** `arm64-v8a` et `x86_64`

> [!CAUTION]
> Les versions récentes du noyau ont introduit un changement cassant qui fait échouer KernelSU Next et peut déclencher un kernel panic sur `x86_64` ! Consultez le site web pour plus d'informations !

---

## 📦 Installation

Consultez le guide d'[Installation](https://kernelsu-next.github.io/webpage/pages/installation.html) pour les instructions de configuration.

---

## 🏅 Contribution

- Rendez-vous sur [Crowdin](https://crowdin.com/project/kernelsu-next) pour soumettre une traduction du gestionnaire !
- Pour signaler des problèmes de sécurité, veuillez consulter [SECURITY.md](/SECURITY.md).

---

## 📜 Licence

- **répertoire `/kernel`:** [GPL-2.0-only](https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html).
- **Tous les autres fichiers:** [GPL-3.0-or-later](https://www.gnu.org/licenses/gpl-3.0.html).

---

## 💸 Dons

Si vous souhaitez soutenir le projet :

- **USDT (BEP20, ERC20)**: `0x0b269716dc00692676e4217e23c7f67abd5f0f3e`
- **USDT (TRC20)**: `TXu6VX8dvJLQPx4WBobjbYT5tefHTDikWo`
- **LTC**: `LMYRqRXPKAFpYncBhNS44W1iwFit14LH1u`

---

## 🙏 Crédits

- [Kernel-Assisted Superuser](https://git.zx2c4.com/kernel-assisted-superuser/about/) – Inspiration conceptuelle
- [Magisk](https://github.com/topjohnwu/Magisk) – Implémentation root centrale
- [Genuine](https://github.com/brevent/genuine/) – Validation de signature APK v2
- [Diamorphine](https://github.com/m0nad/Diamorphine) – Techniques de rootkit
- [KernelSU](https://github.com/tiann/KernelSU) – La base originale qui a rendu KernelSU Next possible
- [Susfs4ksu](https://gitlab.com/simonpunk/susfs4ksu) – Extension de masquage root au niveau du noyau pour KernelSU
- [Susfs4ksu-lkm](https://github.com/inforcqb/susfs4ksu-lkm) – SUSFS porté sous forme de module noyau chargement dynamique

